# Lambda Deploy
Tool which packages, uploads, and deploys AWS lambda functions. 

# Table Of Contents
- [Overview](#overview)
- [Install](#install)
- [Configure](#configure)
- [Use](#use)
    - [Write A CloudFormation Stack](#write-a-cloudformation-stack)
    - [Run](#run)
- [Development](#development)

# Lambda Deploy
Deploys AWS lambda functions by completing the following steps

- Creates a Lambda deployment artifact
- Uploads the deployment artifact to S3
- Deploys a CloudFormation stack
- Creates a GitHub release for the repository

# Install
Add Lambda Deploy as a Git submodule:

```
mkdir -p deploy/
git submodule add git@github.com:AminoPay/lambda-deploy.git deploy/lambda-deploy
```

Cd into the submodule directory and run:

```
pipenv install
```

# Configure
Create a TOML configuration file. Write a section for each stage using 
the following options:

- `package`
    - `lambdas` (Required, Dict[String, List[String]]): Keys are names of
        Lambda functions. Values are lists of source files
    - `pipenv_dir` (Optional, String): Path to directory which contains Pipenv `Pipfile`, defaults to `.`
    - `bucket` (Required, String): Name of the S3 bucket to upload Lambda deployment
        artifacts to
- `deploy`
    - `stack_name` (Required, String): Name to give CloudFormation stack
    - `template_file` (Required, String): CloudFormation stack template file
    - `parameters` (Optional, Dict[String, Any]): CloudFormation parameters to 
        override when deploying the stack
- `release`
    - `template_file` (Optional, String): Path to file with extra release body content. Use Python named format
        parameters. Available parameters: `deploy_inline_config_str`
    - `lambda_artifacts` (Both optional & required, Dict[String, String]): Locations of Lambda deployment artifacts. 
        Optional if the `package` stage is run as well. Otherwise required.

*Note: All paths in configuration options are relative to the Git repository root*

Special configuration in the form of environment variables is required if you are running the `release` stage:

- `GITHUB_TOKEN` (Required, String): GitHub API token with permissions to create a release on your repository
- `CIRCLE_PROJECT_USERNAME` (Required, String): GitHub username of your repository, automatically provided
    by CircleCI
- `CIRCLE_PROJECT_REPONAME` (Require, String): Name of your GitHub repository, automatically provided by CircleCI

# Use
## Write A CloudFormation Stack
Your CloudFormation stack must accept a few parameters to work with the Lambda Deploy tool:

- `Environment`: Deployment environment, either `sand`, `dev`, `prod`
- `LambdaCodeBucket`: The S3 bucket Lambda deployment artifacts are uploaded to
- `<Lambda name>LambdaCodeKey`: The S3 key where a specific Lambda's deployment artifact is located in the code bucket
    - `<Lambda name>` should be the name of a Lambda in the config `package.lambda` option in upper camel case form
        (upper camel case form: `UpperCamelCaseForm`)

## Run
Execute the `lambda_deploy.sh` script.  

Specify the stages you wish to deploy as positional arguments. Use the section 
names from the configuration file.

Pass the location of your TOML configuration file with the `--config,-c` 
argument. Multiple configuration files can be specified. Parameters will be 
overwritten by the last configuration file specified.

# Development
Source code for this tool is located in the `lambda_deploy.py` file.  

Lint this file by running:

```
make lint
```
