#!/usr/bin/env python3

import sys
import logging
import argparse
import os
import os.path
import hashlib
import subprocess
import collections
import json
import time
from urllib.request import urlopen, Request
from datetime import datetime

from typing import Dict, List

import toml
import git
from schema import Schema, Optional, SchemaError
import boto3
import inflection

# Constants
DATE = time.strftime("%Y-%m-%d")

RELEASE_BODY = """
### [Full Change Log]({comparison_url})
### Merged Pull Requests
{pr_list}
### Artifacts
{artifacts_body}
{extra_template_file_str}
"""

ARTIFACTS_BODY_TEMPLATE = """
Artifact S3 Bucket: `{s3_bucket}`
Artifacts for each step:

| Step Name | Location In S3 Bucket |
| --------- | --------------------- |
{artifacts_table}

To deploy pass the following arguments to the `lambda_deploy.sh` script:

```
--inline-config "{deploy_inline_config_str}"
```
"""

# Default configuration values
DEFAULT_PKG_PIPENV_DIR = '.'

# Configuration schema
CONFIG_SCHEMA = {
    'package': {
        'lambdas': {str: [str]},
        Optional('pipenv_dir'): str,
        'bucket': str
    },
    'deploy': {
        'stack_name': str,
        'template_file': str,
        Optional('parameters'): {str: object}
    }
}


def main() -> int:
    """ Entry point
    Return: Exit code
    """
    # Setup logger
    logger = logging.getLogger('deploy')

    logger.setLevel(logging.DEBUG)

    hndlr = logging.StreamHandler(sys.stdout)
    hndlr.setFormatter(logging.Formatter("%(name)s [%(levelname)s] %(message)s"))

    logger.addHandler(hndlr)

    # https://stackoverflow.com/questions/22081209/find-the-root-of-the-git-repository-where-the-file-lives/22081487
    script_path = os.path.dirname(os.path.realpath(__file__))

    # Check the most recent version of the Lambda Deploy tool is running
    """
    if not check_most_recent_tool_version(logger=logger, script_path=script_path):
        return 1
    """

    # Parse arguments
    parser = argparse.ArgumentParser(description="Lambda deploy script")
    parser.add_argument('stages',
                        help="Name of the lambda deploy stages to run. Note: the release stage can only be invoked " +
                             "if the package stage is invoked",
                        choices=['all', 'package', 'deploy', 'release'],
                        nargs='+')
    parser.add_argument('--env', '-e',
                        help="Deployment environment",
                        choices=['sand', 'dev', 'prod'],
                        default='dev')
    parser.add_argument('--inline-config',
                        help="JSON configuration object passed via a command line argument",
                        action='append',
                        default=[])
    parser.add_argument('--save-lambda-artifact-locations',
                        help="If present the S3 keys of Lambda deployment artifacts will be saved in the specified " +
                             "file in JSON format. Can only be provided if the 'package' stage is being invoked")
    required_parser = parser.add_argument_group('required arguments')
    required_parser.add_argument('--config', '-c',
                                 help="Configuration file path",
                                 action='append',
                                 required=True)
    args = parser.parse_args()

    # Get Git repo root directory
    # https://stackoverflow.com/questions/5137497/find-current-directory-and-files-directory
    git_repo = git.Repo(resolve_path(script_path, '..'), search_parent_directories=True)
    git_root = git_repo.git.rev_parse('--show-toplevel')

    # If the 'all' stage is specified, replace with the individual stage names
    if 'all' in args.stages:
        args.stages = ['package', 'deploy', 'release']

    # Check if the --save-lambda-artifact-locations argument is specified, but the 'package' stage is not
    if args.save_lambda_artifact_locations and 'package' not in args.stages:
        logger.error("--save-lambda-artifact-locations argument can not be provided if 'package' stage is " +
                     "not specified")
        return 1

    # Modify config schema based on which stages are invoked
    if 'package' not in args.stages:
        CONFIG_SCHEMA.update({
            'release': {
                'lambda_artifacts': {str: str},
                Optional('template_file'): str
            }
        })
    else:
        CONFIG_SCHEMA.update({
            Optional('release'): {
                Optional('template_file'): str
            }
        })

    # Resolve CLI argument paths relative to Git root
    args.config = [resolve_path(git_root, conf_path) for conf_path in args.config]

    # Read configuration file
    config = {}

    for config_path in args.config:
        with open(config_path, 'r') as config_f:
            # Check if json or yaml
            extension = os.path.splitext(config_path)[1]

            if extension == '.toml':
                new_config = toml.load(config_f)
            elif extension == '.json':
                new_config = json.load(config_f)
            else:
                logger.error("Cannot load configuration files with file extension: {}".format(extension))
                return 1

            config = deep_update_dict(config, new_config)

    # Read inline configuration
    for inline_config in args.inline_config:
        new_config = json.loads(inline_config)
        config = deep_update_dict(config, new_config)

    # Validate configuration
    try:
        Schema(CONFIG_SCHEMA).validate(config)
    except SchemaError as e:
        logger.error("Configuration is not formatted correctly: {}".format(e))
        return 1

    # Set default configuration values
    if 'pipenv_dir' not in config['package']:
        config['package']['pipenv_dir'] = DEFAULT_PKG_PIPENV_DIR

    if 'release' not in config:
        config['release'] = {}

    if 'parameters' not in config['deploy']:
        config['deploy']['parameters'] = {}

    # Resolve paths in configuration relative to Git root
    for lambda_name in config['package']['lambdas']:
        config['package']['lambdas'][lambda_name] = [resolve_path(git_root, lambda_src_file) for lambda_src_file in
                                                     config['package']['lambdas'][lambda_name]]

    config['package']['pipenv_dir'] = resolve_path(git_root, config['package']['pipenv_dir'])

    if 'release' in config and 'template_file' in config['release']:
        config['release']['template_file'] = resolve_path(git_root, config['release']['template_file'])

    config['deploy']['template_file'] = resolve_path(git_root, config['deploy']['template_file'])

    if args.save_lambda_artifact_locations:
        args.save_lambda_artifact_locations = resolve_path(git_root, args.save_lambda_artifact_locations)

    # Prefix stack name configuration option with environment
    config['deploy']['stack_name'] = "{}-{}".format(args.env, config['deploy']['stack_name'])

    # Print normalize configuration options
    logger.info("#################")
    logger.info("# Configuration #")
    logger.info("#################")

    logger.info("===== Command line options")
    for arg_key in vars(args):
        logger.info("    {}: {}".format(arg_key, getattr(args, arg_key)))

    logger.info("===== Configuration file")
    config_str_lines = json.dumps(config, indent=4, sort_keys=True).split('\n')

    for config_str_line in config_str_lines:
        logger.info("    {}".format(config_str_line))

    # Package
    if 'package' in args.stages:
        logger.info("###########")
        logger.info("# Package #")
        logger.info("###########")

        logger.info("===== Installing dependencies")
        subprocess.run(['pipenv', 'install'], cwd=config['package']['pipenv_dir'])

        logger.info("===== Packaging Lambda functions")
        local_lambda_artifact_paths = build_lambda_artifacts(logger=logger,
                                                             lambda_functions=config['package']['lambdas'],
                                                             git_root=git_root,
                                                             pipenv_dir=config['package']['pipenv_dir'])

        s3_lambda_artifact_keys = upload_lambda_artifacts(logger=logger,
                                                          local_lambda_artifact_paths=local_lambda_artifact_paths,
                                                          bucket=config['package']['bucket'],
                                                          env=args.env,
                                                          stack_name=config['deploy']['stack_name'])

        config['release']['lambda_artifacts'] = s3_lambda_artifact_keys

        if args.save_lambda_artifact_locations:
            logger.info("===== Saving Lambda artifact locations at {}".format(args.save_lambda_artifact_locations))
            artifact_locations_out_obj = {
                'release': {
                    'lambda_artifacts': s3_lambda_artifact_keys
                }
            }

            with open(args.save_lambda_artifact_locations, 'w') as f:
                json.dump(artifact_locations_out_obj, f)

    # Deploy
    if 'deploy' in args.stages:
        logger.info("##########")
        logger.info("# Deploy #")
        logger.info("##########")

        logger.info("===== Deploying ")

        deploy_cloudformation_stack(logger=logger,
                                    s3_lambda_artifact_keys=config['release']['lambda_artifacts'],
                                    bucket=config['package']['bucket'],
                                    env=args.env,
                                    stack_name=config['deploy']['stack_name'],
                                    stack_template_file=config['deploy']['template_file'],
                                    extra_parameters=config['deploy']['parameters'])

    # Release
    if 'release' in args.stages:
        logger.info("###########")
        logger.info("# Release #")
        logger.info("###########")

        release(logger=logger, bucket=config['package']['bucket'],
                s3_lambda_artifact_keys=config['release']['lambda_artifacts'],
                extra_template_file=config['release']['template_file'])

    return 0


def release(logger: logging.Logger, bucket: str, s3_lambda_artifact_keys: Dict[str, str], extra_template_file):
    """ Creates a new GitHub release
    Args:
        - logger
        - bucket: S3 bucket Lambda artifacts were uploaded to
        - s3_lambda_artifact_keys: S3 keys in bucket of Lambda deployment artifacts. Keys are Lambda function names,
            values are S3 keys
    """
    # Load environment configuration
    logger.info("===== Loading configuration")

    GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN', None)
    CIRCLE_PROJECT_USERNAME = os.environ.get('CIRCLE_PROJECT_USERNAME', None)
    CIRCLE_PROJECT_REPONAME = os.environ.get('CIRCLE_PROJECT_REPONAME', None)

    GITHUB_URL = "https://api.github.com/repos/{}/{}".format(CIRCLE_PROJECT_USERNAME, CIRCLE_PROJECT_REPONAME)

    RELEASES_URL = GITHUB_URL + "/releases"
    PULLS_URL = GITHUB_URL + "/pulls"
    TREE_URL = GITHUB_URL + "/tree"
    RELEASES_URL = GITHUB_URL + "/releases"
    COMPARE_URL = GITHUB_URL + "/compare"

    missing_conf_envs = []

    if not GITHUB_TOKEN:
        missing_conf_envs.append('GITHUB_TOKEN')

    if not CIRCLE_PROJECT_USERNAME:
        missing_conf_envs.append('CIRCLE_PROJECT_USERNAME')

    if not CIRCLE_PROJECT_REPONAME:
        missing_conf_envs.append('CIRCLE_PROJECT_REPONAME')

    # Get tag for new release
    logger.info("===== Generating release tag")

    releases_result = get_releases(RELEASES_URL=RELEASES_URL, github_token=GITHUB_TOKEN)
    tag = generate_tag(releases=releases_result)

    # Get changes since last release
    logger.info("===== Retrieving pull requests since last release")
    pulls_result = get_pulls(PULLS_URL=PULLS_URL, releases=releases_result, github_token=GITHUB_TOKEN)

    # Generate release body
    logger.info("===== Generating release body")
    body = generate_release_body(TREE_URL=TREE_URL, COMPARE_URL=COMPARE_URL, pulls=pulls_result,
                                 releases=releases_result, tag=tag, bucket=bucket,
                                 s3_lambda_artifact_keys=s3_lambda_artifact_keys,
                                 extra_template_file=extra_template_file)

    # Create release
    logger.info("===== Releasing")
    create_release(RELEASES_URL=RELEASES_URL, tag=tag, release_body=body, github_token=GITHUB_TOKEN)


def deploy_cloudformation_stack(logger: logging.Logger, s3_lambda_artifact_keys: Dict[str, str], bucket: str, env: str,
                                stack_name: str, stack_template_file: str, extra_parameters: Dict[str, str]):
    """ Deploy CloudFormation stack
    Args:
        - logger
        - s3_lambda_artifact_keys: Location of Lambda function deployment artifacts in the S3 code bucket. Keys are
            Lambda names, values are S3 keys representing the location of Lambda deployment artifacts
        - bucket: S3 bucket Lambda deployment artifacts are uploaded to
        - env: Deployment environment
        - stack_name: CloudFormation stack name
        - stack_template_file: Path to CloudFormation stack template file
        - extra_parameters: Extra parameters to pass to the CloudFormation stack
    """
    # Assemble CloudFormation deploy command
    cf_deploy_args = ['aws', 'cloudformation', 'deploy', '--stack-name', stack_name, '--template-file',
                      stack_template_file, '--capabilities', 'CAPABILITY_NAMED_IAM', '--parameter-overrides']

    cf_param_overrides = {
        'Environment': env,
        'LambdaCodeBucket': bucket
    }

    cf_param_overrides.update(extra_parameters)

    for lambda_name in s3_lambda_artifact_keys:
        camel_lambda_name = inflection.camelize(lambda_name)
        cf_param_lambda_name = "{}LambdaCodeKey".format(camel_lambda_name)

        cf_param_overrides[cf_param_lambda_name] = s3_lambda_artifact_keys[lambda_name]

    for param_key in cf_param_overrides:
        cf_deploy_args.append("{}={}".format(param_key, cf_param_overrides[param_key]))

    # Run CloudFormation deploy command
    run_res = subprocess.run(cf_deploy_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Print run results
    for stdout_line in run_res.stdout.decode().split('\n'):
        if len(stdout_line) == 0:
            continue

        logger.info("    {}".format(stdout_line))

    for stderr_line in run_res.stderr.decode().split('\n'):
        if len(stderr_line) == 0:
            continue

        logger.error("    {}".format(stderr_line))

    # Check deploy was successful
    if run_res.returncode != 0:
        logger.error("    Failed")
        if 'aws cloudformation describe-stack-events' in run_res.stderr.decode():
            subprocess.run(['aws', 'cloudformation', 'describe-stack-events', '--stack-name', stack_name])

        raise ValueError("Failed to deploy CloudFormation stack")
    else:
        logger.info("    Success")


def upload_lambda_artifacts(logger: logging.Logger, local_lambda_artifact_paths: Dict[str, str],
                            bucket: str, env: str, stack_name: str) -> Dict[str, str]:
    """ Upload Lambda function deployment artifacts to S3
    Args:
        - logger
        - local_lambda_artifact_paths: Locations of Lambda deployment artifacts on disk. Keys are Lambda function
            names. Values are paths to Lambda deployment artifacts on the disk
        - bucket: S3 bucket to upload Lambda deployment artifacts to
        - env: Deployment environment

    Returns:
        - S3 keys of Lambda deployment artifacts in bucket
    """
    s3 = boto3.client('s3')

    s3_keys = {}

    logger.info("===== Uploading Lambda deployment artifacts")

    # Upload artifacts
    for lambda_name in local_lambda_artifact_paths:
        # Compute S3 key name
        file_path = local_lambda_artifact_paths[lambda_name]
        file_name = os.path.basename(file_path)

        upload_parent_dir = 'snapshot'
        if env == 'prod':
            upload_parent_dir = 'release'

        s3_key = "{}/lambdas/{}/{}".format(upload_parent_dir, stack_name, file_name)
        s3_uri = "s3://{}/{}".format(bucket, s3_key)

        s3_keys[lambda_name] = s3_key

        # Print upload status
        logger.info("")
        logger.info("    {}".format(lambda_name))
        logger.info("    {}".format('=' * len(lambda_name)))
        logger.info("    {}".format(s3_uri))

        # Check if already uploaded
        ls_resp = s3.list_objects_v2(Bucket=bucket, Prefix=s3_key)

        if 'Contents' in ls_resp and len(ls_resp['Contents']) > 0:
            logger.info("    Already uploaded")
            continue

        # Upload if not already
        s3.upload_file(file_path, bucket, s3_key)

        logger.info("    Uploaded")

    return s3_keys


def build_lambda_artifacts(logger: logging.Logger, lambda_functions: Dict[str, List[str]],
                           git_root: str, pipenv_dir: str) -> Dict[str, str]:
    """ Creates Lambda deployment artifacts
    Args:
        - logger
        - lambda_functions: Keys are Lambda function names, values are a list of function source file
        - git_root: Path to Git repository root
        - pipenv_dir: Directory Pipenv exists in

    Returns:
        - Location of Lambda deployment artifacts on local disk
            - Keys are Lambda function names from lambda_functions argument
            - Values paths to deployment artifacts on local disk
    """
    local_artifact_paths = {}

    git_head_sha = get_git_head_sha(git_root=git_root)
    pipenv_lib_dir = get_pipenv_lib_dir(pipenv_dir=pipenv_dir)

    for lambda_name in lambda_functions:
        lambda_files = lambda_functions[lambda_name]

        # Get checksum of Lambda source files
        files = []
        dirs = []

        for src_path in lambda_files:
            if os.path.isdir(src_path):
                dirs.append(src_path)
            else:
                files.append(src_path)

        checksum = compute_checksum(files=files, dirs=dirs)

        # Generate artifact output path
        artifact_out_path = "/tmp/{lambda_name}-git-{git_head}-src-checksum-{checksum}".format(lambda_name=lambda_name,
                                                                                               git_head=git_head_sha,
                                                                                               checksum=checksum)
        artifact_out_path += '.zip'
        local_artifact_paths[lambda_name] = artifact_out_path

        # Print info about step artifact build
        logger.info("")
        logger.info("    {}".format(lambda_name))
        logger.info("    {}".format('=' * len(lambda_name)))
        logger.info("    {}".format(artifact_out_path))

        # Check if artifact already exists
        if os.path.isfile(artifact_out_path):
            logger.info("    Already exists")
            continue

        # Zip lambda source files
        src_zip_cmd = ['zip', '-r', artifact_out_path]
        src_zip_cmd.extend(lambda_files)
        subprocess.run(src_zip_cmd, cwd=git_root, stdout=subprocess.PIPE)

        # Zip Pipenv virtual environment library file
        lib_zip_cmd = ['zip', '-r', artifact_out_path, '.']

        subprocess.run(lib_zip_cmd, cwd=pipenv_lib_dir, stdout=subprocess.PIPE)

        # Print build status
        logger.info("    Built")

    return local_artifact_paths


def compute_checksum(files: List[str], dirs: List[str]) -> str:
    """ Computes the checksum of the provided files
    Args:
        - files: Files to compute checksum of
        - dirs: Directories to hash all files in

    Returns:
        - Checksum of provided files
    """
    # Get file paths to hash
    hash_files = files

    for dir_path in dirs:
        for root, _, files in os.walk(dir_path):
            for file in files:
                hash_files.append(resolve_path(root, file))

    # Hash
    hash_md5 = hashlib.md5()

    for file_path in hash_files:
        with open(file_path, 'rb') as file:
            hash_md5.update(file.read())

    return hash_md5.hexdigest()


def deep_update_dict(d: Dict[object, object], u: Dict[object, object]) -> Dict[object, object]:
    """ Updates dict d with new values from dict u
    Handles nested dicts, unlike the standard dict.update method

    https://stackoverflow.com/a/3233356

    Args:
        - d: Dict to update
        - u: New dict values
    """
    for k, v in u.items():
        if isinstance(v, collections.Mapping):
            d[k] = deep_update_dict(d.get(k, {}), v)
        else:
            d[k] = v
    return d


def get_git_head_sha(git_root: str) -> str:
    """ Get Git repo HEAD sha
    Args:
        - git_root: Path to Git repository root directory

    Returns:
        - Git repo HEAD sha
    """
    repo = git.Repo(git_root)
    return repo.head.commit.hexsha


def get_pipenv_lib_dir(pipenv_dir: str) -> str:
    """ Gets the directory the Pipenv virtual environment libraries exist in
    Args:
        - pipenv_dir: Directory Pipenv file exists in

    Returns:
        - Directory Pipenv managed virtual environment libraries exist in
    """
    venv_find_call = subprocess.run(['pipenv', '--venv'], cwd=pipenv_dir, stdout=subprocess.PIPE)
    venv_dir = venv_find_call.stdout.strip().decode()

    return os.path.abspath(resolve_path(venv_dir, 'lib/python3.6/site-packages'))


def resolve_path(root: str, file_path: str) -> str:
    """ Finds the absolute path
    Args:
        - root: Root directory
        - file_path: File to find path of

    Returns:
        - Absolute path
    """
    return os.path.abspath(os.path.join(root, file_path))


def check_most_recent_tool_version(logger: logging.Logger, script_path: str) -> bool:
    """ Ensures that the most recent version of the Lambda Deploy tool is running
    Args:
        - logger
        - script_path: Directory Lambda Deploy script file is located

    Returns:
        - True: If latest Lambda Deploy version is installed
        - False: If a newer version of the Lambda Deploy version is available
    """
    logger.info("#############################")
    logger.info("# Checking for tool updates #")
    logger.info("#############################")

    # Get latest remote commit sha
    logger.info("===== Retrieving latest version from GitHub")

    git_obj = git.Git(script_path)
    ls_resp = git_obj.ls_remote(['origin', 'HEAD'])

    remote_sha = ls_resp.split('\t')[0]

    # Get latest local git commit sha
    logger.info("===== Retrieving local version")

    repo = git.Repo(script_path)
    local_sha = repo.head.commit.hexsha

    # Check if we have latest
    logger.info("===== Ensuring local version matches latest version")

    if remote_sha != local_sha:
        logger.error("    A newer version of the Lambda Deploy tool is available")
        logger.error("    Local version: {}".format(local_sha))
        logger.error("    Latest version: {}".format(remote_sha))
        logger.error("    Run the following command to update:")
        logger.error("        git submodule update --remote")

        return False
    else:
        logger.info("    Up to date")
        return True


def get_pulls(PULLS_URL: str, releases, github_token: str) -> List[object]:
    """ Get pull requests since last release
    Args:
        - releases: GitHub releases
        - github_token

    Returns:
        - Pull requests since last release
    """
    url_pulls = PULLS_URL + "?state=closed"

    # get all commits since the last release
    get_pulls_since_req = Request(url_pulls)
    get_pulls_since_req.add_header('Authorization', "token {}".format(github_token))
    get_pulls_since_resp = urlopen(get_pulls_since_req)
    pulls = json.loads(get_pulls_since_resp.read().decode('utf-8'))
    good_pulls = []
    if len(releases) > 0:
        last_release_date = datetime.strptime(releases[0]['published_at'], "%Y-%m-%dT%H:%M:%Sz")
    else:
        last_release_date = datetime(1970, 1, 1, 0, 0)
    for pull in pulls:
        closed_date = datetime.strptime(pull['closed_at'], "%Y-%m-%dT%H:%M:%Sz")
        if closed_date > last_release_date:
            good_pulls.append(pull)
    return good_pulls


def get_releases(RELEASES_URL: str, github_token: str):
    """ gets all releases via GH API
    Args:
        - github_token
    """
    get_releases_req = Request(RELEASES_URL)
    get_releases_req.add_header('Authorization', "token {}".format(github_token))
    get_releases_resp = urlopen(get_releases_req)
    releases = json.loads(get_releases_resp.read().decode('utf-8'))
    return releases


def generate_tag(releases) -> str:
    """ Generate new release tag based on previous releases
    Args:
        - release: Previous GitHub releases

    Returns:
        - New release tag
    """
    release_tags = [release['tag_name'] for release in releases]
    # want to make sure not to repeat a tag, so we start w/ version one for the day & increment until uniqueness
    v = 1
    tag = "{}-{}".format(DATE, v)
    while tag in release_tags:
        v += 1
        tag = "{}-{}".format(DATE, v)
    return tag


def generate_release_body(TREE_URL: str, COMPARE_URL: str, pulls, releases, tag, bucket, s3_lambda_artifact_keys,
                          extra_template_file: str = None):
    """ Create GitHub release body
    Args:
        - pulls: List of pull requests
        - releases: GitHub release for repo
        - tag: GitHub release tag
        - bucket: S3 bucket Lambda deployment artifacts are uploaded to
        - s3_lambda_artifact_keys: Locations of Lambda deployment artifacts in S3 bucket. Keys are Lambda function
            names, values are S3 keys
        - extra_template_file: File with extra content to append to release body
    """
    # Get compare url
    tree_url = TREE_URL + "/{}".format(tag)
    comparison_url = generate_diff_link(COMPARE_URL=COMPARE_URL, prev_release_tag=releases[0]['tag_name'],
                                        new_release_tag=tag) if releases else tree_url

    # Make PR list
    pr_list = ""

    for pull in pulls:
        pr_list += "{} [#{}]({}) ([{}]({}))\n".format(pull['title'], pull['number'], pull['html_url'],
                                                      pull['user']['login'], pull['user']['html_url'])

    # Make table of artifact locations per step
    artifacts_table_rows = []
    for lambda_name in s3_lambda_artifact_keys:
        artifacts_table_rows.append("| `{}` | `{}` |".format(lambda_name, s3_lambda_artifact_keys[lambda_name]))

    # Make string representation of artifact locations
    deploy_inline_config_str = json.dumps({
        'package': {
            'bucket': bucket
        },
        'release': {
            'lambda_artifacts': s3_lambda_artifact_keys
        }
    }).replace("\"", '\\"')

    artifacts_body = ARTIFACTS_BODY_TEMPLATE.format(s3_bucket=bucket,
                                                    artifacts_table='\n'.join(artifacts_table_rows),
                                                    deploy_inline_config_str=deploy_inline_config_str)

    # Load extra template file
    extra_template_file_str = ""
    if extra_template_file:
        with open(extra_template_file, 'rt') as f:
            extra_template_file_str = f.read().format(deploy_inline_config_str=deploy_inline_config_str)

    return RELEASE_BODY.format(comparison_url=comparison_url, pr_list=pr_list, artifacts_body=artifacts_body,
                               deploy_inline_config_str=deploy_inline_config_str,
                               extra_template_file_str=extra_template_file_str)


def generate_diff_link(COMPARE_URL: str, prev_release_tag, new_release_tag):
    return COMPARE_URL + "/{}...{}".format(prev_release_tag, new_release_tag)


def create_release(RELEASES_URL: str, tag: str, release_body: str, github_token: str):
    """ Creates GitHub release
    Args:
        - tag: Release tag
        - release_body: Contents of release
        - github_token

    Raises:
        - ValueError: If an error occurs while calling the GitHub API
    """
    new_release_data = json.dumps({
        'tag_name': tag,
        'name': tag,
        'body': release_body
    }).encode('utf-8')

    create_new_release_req = Request(RELEASES_URL, new_release_data, {'Content-Type': 'application/json'})
    create_new_release_req.add_header('Authorization', "token {}".format(github_token))
    with urlopen(create_new_release_req) as response:
        if 200 > response.status > 300:
            raise ValueError("Error while creating GitHub release: {} - {}".format(response.status, response.reason))


if __name__ == '__main__':
    sys.exit(main())
